<div class="barra">
    <ul>
    <img class="logo" src="./img/logos.png" alt="Erro ao carregar imagem" width="50px">
        <div class="menu_itens">
            <li><a href="./cadastro.php">CADASTRO</a></li>
            <li><a href="./visualizacao.php">VISUALIZAÇÃO</a></li>
            <li><a href="./menu.php">SAIR</a></li>
        </div>
    </ul>
</div>